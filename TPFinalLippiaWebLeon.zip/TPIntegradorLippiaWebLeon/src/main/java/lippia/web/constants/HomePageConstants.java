package lippia.web.constants;

public class HomePageConstants {
    public static final String SHOP_BUTTON = "xpath://*[@id='menu-item-40']/a";

    public static final String HOME_FROM_SHOP_BUTTON = "xpath://*[@id='content']/nav/a";

    public static final String FIRST_IMAGE_ARRIVAL_BUTTON = "xpath://*[@id='text-22-sub_row_1-0-2-0-0']/div/ul/li/a[1]";

    public static final String ADD_TO_BASKET_BUTTON = "xpath://*[@id='product-160']/div[2]/form/button";

    public static final String ITEM_LINK_BUTTON = "xpath://*[@id='wpmenucartli']/a/span[1]";

    public static final String PROCEED_TO_CHECKOUT = "xpath://*[@id='page-34']/div/div[1]/div/div/div/a";

    public static final String DISPLAY_COUPON_BUTTON = "xpath://*[@id='page-35']/div/div[1]/div[2]/a";

    public static final String COUPON_TEXTBOX = "xpath://*[@id='coupon_code']";

    public static final String ADD_COUPON_BUTTON = "xpath://*[@id='page-35']/div/div[1]/form[2]/p[2]/input";

    public static final String NAME_TEXTBOX = "xpath://*[@id='billing_first_name']";

    public static final String LNAME_TEXTBOX = "xpath://*[@id='billing_last_name']";

    public static final String EMAIL_TEXTBOX = "xpath://*[@id='billing_email']";

    public static final String PHONE_TEXTBOX = "xpath://*[@id='billing_phone']";

    public static final String COUNTRY_DROP_BUTTON = "xpath://*[@id='s2id_billing_country']/a/span[2]/b";

    public static final String COUNTRY_TEXTBOX = "xpath://*[@id='s2id_autogen1_search']";

    public static final String COUNTRY_SEARCH_MATCH = "xpath://*[@id='select2-results-1']/li";

    public static final String ADRESS_TEXTBOX = "xpath://*[@id='billing_address_1']";

    public static final String TOWN_CITY_TEXTBOX = "xpath://*[@id='billing_city']";

    public static final String POSTCODE_TEXTBOX = "xpath://*[@id='billing_postcode']";

    public static final String STATE_DROP_BUTTON = "xpath://*[@id='s2id_billing_state']/a/span[2]/b";

    public static final String STATE_TEXTBOX = "xpath://*[@id='s2id_autogen2_search']";

    public static final String STATE_SEARCH_MATCH = "xpath://*[@id='select2-results-2']/li";

    public static final String SELECTABLE_CHEQUE = "xpath://*[@id='payment_method_cheque']";

    public static final String PLACE_ORDER_BUTTON = "xpath://*[@id='place_order']";

    public static final String BILLING_DETAILS = "Xpath: //*[@id='page-35']/div/div[1]";

    public static final String ORDER_DETAILS = "xpath: //*[@id='page-35']/div/div[1]";

}
