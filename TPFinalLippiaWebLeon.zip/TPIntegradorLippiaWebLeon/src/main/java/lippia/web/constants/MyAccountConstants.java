package lippia.web.constants;

public class MyAccountConstants {

    // Constants de los escenarios de Login y My Account
    public static final String MY_ACCOUNT_BUTTON = "xpath://*[@id='menu-item-50']/a";

    public static final String LOGIN_BUTTON = "xpath://*[@id='customer_login']/div[1]/form/p[3]/input[3]";

    public static final String LUSERNAME_TEXTBOX = "xpath://*[@id='username']";

    public static final String LPASSWORD_TEXTBOX = "xpath://*[@id='password']";

    public static final String SING_OUT_BUTTON = "xpath://*[@id='page-36']/div/div[1]/div/p[1]/a";

    public static final String ERROR_LOGIN_CONFIRMATION = "xpath://*[@id='page-36']/div/div[1]/ul";

    // Constants exclusivas de los escenarios de Registration
    public static final String REGISTER_BUTTON = "xpath://*[@id='customer_login']/div[2]/form/p[3]/input[3]";

    public static final String EMAIL_REGISTRATION_TEXTBOX = "xpath://*[@id='reg_email']";

    public static final String PASSWORD_REGISTRATION_TEXTBOX = "xpath://*[@id='reg_password']";

    public static final String PASSWORD_ERROR_MESSAGE = "xpath://*[@id='page-36']/div/div[1]/ul/li";

    // Constants exclusivas de los escenarios de My Account
    public static final String ACCOUNT_DETAILS = "xpath://*[@id='page-36']/div/div[1]/nav/ul/li[5]/a";

    public static final String ACCOUNT_LOGOUT = "xpath://*[@id='page-36']/div/div[1]/nav/ul/li[6]/a";
}
