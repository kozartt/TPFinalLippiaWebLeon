package lippia.web.constants;

public class ShopConstants {

    public static final String ITEM_LINK_SHOP = "xpath://*[@id='wpmenucartli']/a/span[1]";

    public static final String ADD_BASKET_FROM_SHOP = "xpath://*[@id='content']/ul/li[1]/a[2]";

    public static final String TOTAL = "xpath: //*[@id='page-34']/div/div[1]/div/div/table/tbody/tr[3]/td/strong/span";

    public static final String SUBTOTAL = "xpath: //*[@id='page-34']/div/div[1]/div/div/table/tbody/tr[1]/td/span";

    public static final String TAX = "xpath: //*[@id='page-34']/div/div[1]/div/div/table/tbody/tr[2]/td/span";

}
