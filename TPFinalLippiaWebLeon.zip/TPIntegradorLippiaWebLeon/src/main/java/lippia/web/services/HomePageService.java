package lippia.web.services;

import static lippia.web.constants.HomePageConstants.*;
import static lippia.web.services.GeneralToolsService.*;

public class HomePageService {

    public static void callMethods(String cupon,String firstName,String lastName,String email,String phone,String country,String adress, String town,String postCode,String state){
        clickElement(DISPLAY_COUPON_BUTTON);
        setInput(COUPON_TEXTBOX,cupon);
        clickElement(ADD_COUPON_BUTTON);
        setInput(NAME_TEXTBOX,firstName);
        setInput(LNAME_TEXTBOX,lastName);
        setInput(EMAIL_TEXTBOX,email);
        setInput(PHONE_TEXTBOX,phone);
        clickElement(COUNTRY_DROP_BUTTON);
        setInput(COUNTRY_TEXTBOX,country);
        clickElement(COUNTRY_SEARCH_MATCH);
        setInput(ADRESS_TEXTBOX,adress);
        setInput(TOWN_CITY_TEXTBOX,town);
        setInput(POSTCODE_TEXTBOX,postCode);
        clickElement(STATE_DROP_BUTTON);
        setInput(STATE_TEXTBOX,state);
        clickElement(STATE_SEARCH_MATCH);
    }
}
