package lippia.web.services;

import com.crowdar.core.actions.ActionManager;
import com.crowdar.core.actions.WebActionManager;
import com.crowdar.driver.DriverManager;
import org.testng.Assert;

public class GeneralToolsService {


    public static void verifyCurrentUrl(String expectedUrl){
        String currentUrl = DriverManager.getDriverInstance().getCurrentUrl();
        Assert.assertEquals(currentUrl , expectedUrl);
    }

    public static void verifyElementPresence(String element){
        Assert.assertTrue(WebActionManager.isPresent(element));}


        public static void clickElement(String element){
        WebActionManager.waitPresence(element);
        WebActionManager.click(element , false);
    }

    public static int borraDecimal(String input) {
        // Verificar si la cadena no es nula y contiene al menos un punto
        if (input != null && input.contains(".")) {
            // Encontrar la posición del primer punto
            int indicePunto = input.indexOf(".");

            // Utilizar substring para obtener la parte de la cadena antes del punto
            String parteEntera = input.substring(0, indicePunto);

            // Convertir la parte entera a un número entero
            return Integer.parseInt(parteEntera);
        } else {
            // Manejar el caso de una cadena sin punto
            System.out.println("La cadena no contiene un punto.");
            return 0; // Otra acción adecuada para manejar el caso
        }
    }

    public static String borrarPrimerCaracter(String input) {
        // Verificar si la cadena no es nula y tiene al menos un carácter
        if (input != null && input.length() > 0) {
            // Utilizar substring para obtener la cadena sin el primer carácter
            return input.substring(1);
        } else {
            // Manejar el caso de una cadena vacía o nula
            System.out.println("La cadena es nula o vacía.");
            return input;
        }
    }

    public static void setInput(String element ,String inputText){
        ActionManager.setInput(element,inputText);
    }

}