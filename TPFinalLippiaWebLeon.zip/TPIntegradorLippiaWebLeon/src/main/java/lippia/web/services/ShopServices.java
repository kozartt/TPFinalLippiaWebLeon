package lippia.web.services;

import com.crowdar.core.actions.WebActionManager;
import lippia.web.constants.ShopConstants;
import org.testng.Assert;

public class ShopServices {

    public static void Comparacion() {
        boolean compare;
        String totalPrice = WebActionManager.getText(ShopConstants.TOTAL);
        totalPrice = GeneralToolsService.borrarPrimerCaracter(totalPrice);
        int total = GeneralToolsService.borraDecimal(totalPrice);
        String SubTotalPrice = WebActionManager.getText(ShopConstants.SUBTOTAL);
        SubTotalPrice = GeneralToolsService.borrarPrimerCaracter(SubTotalPrice);
        int subtotal = GeneralToolsService.borraDecimal(SubTotalPrice);
        Assert.assertNotEquals(total, subtotal);
        if(total > subtotal){
            compare = true;
        }else{
            compare = false;
        }
        Assert.assertTrue(compare);
    }

    public static void Porcentajes() {
        String subSubTotal = WebActionManager.getText(ShopConstants.SUBTOTAL);
        subSubTotal = GeneralToolsService.borrarPrimerCaracter(subSubTotal);
        int subTotal = GeneralToolsService.borraDecimal(subSubTotal);
        int porcentaje = 2;
        int porcentajeTotal = 100;
        int result = (subTotal * porcentaje) / porcentajeTotal;
        String TaxPrice = WebActionManager.getText(ShopConstants.TAX);
        TaxPrice = GeneralToolsService.borrarPrimerCaracter(TaxPrice);
        Assert.assertEquals(result, GeneralToolsService.borraDecimal(TaxPrice));
        System.out.println(result);
    }
}
