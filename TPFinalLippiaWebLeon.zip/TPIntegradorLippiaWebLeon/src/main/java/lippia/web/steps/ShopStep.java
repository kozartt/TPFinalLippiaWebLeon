package lippia.web.steps;

import com.crowdar.core.PageSteps;
import io.cucumber.java.en.*;

import static lippia.web.constants.HomePageConstants.*;
import static lippia.web.constants.ShopConstants.*;
import static lippia.web.services.GeneralToolsService.*;
import static lippia.web.services.ShopServices.*;

public class ShopStep extends PageSteps {

    @When("Hago click en el boton Shop")
    public void clickShopM(){clickElement(SHOP_BUTTON);}

    @And("Hago click en Add to Basket")
    public void clickAddToBasket(){clickElement(ADD_BASKET_FROM_SHOP);}

    @And("Hago click en el Item link")
    public void clickItemL(){clickElement(ITEM_LINK_SHOP);}

    @And("verifico que el total sea menor que el subtotal")
    public void verifyTotalAndSubtotal() {Comparacion();}

    @Then("Verifico si el impuesto es del 2 o del 5 por ciento")
    public void veifyTax() {Porcentajes();}
}
