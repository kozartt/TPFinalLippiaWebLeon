package lippia.web.steps;

import com.crowdar.core.PageSteps;
import com.crowdar.core.actions.WebActionManager;
import io.cucumber.java.en.*;

import static lippia.web.constants.HomePageConstants.*;
import static lippia.web.services.HomePageService.*;
import static lippia.web.services.GeneralToolsService.*;
//import static lippia.web.services.UtilService.clickElement;

public class HomePageSteps extends PageSteps{

    @Given("Estoy en la URL (.*)")
    public void homeURL(String url){
        WebActionManager.navigateTo("https://practice.automationtesting.in");}

    @When("Hago click en el boton Shop menu")
    public void clickShopButton(){clickElement(SHOP_BUTTON);}

    @And("Hago click en el boton Home menu")
    public void clickHomeButton() {clickElement(HOME_FROM_SHOP_BUTTON);}

    @And("Hago click en una imagen de Arrivals")
    public void clickImagenArrival() {clickElement(FIRST_IMAGE_ARRIVAL_BUTTON);}

    @And("Hago click en el boton Add To Basket, añadiendo asi un producto al canasto")
    public void clickAddToBasketButton() {clickElement(ADD_TO_BASKET_BUTTON);}

    @And("Hago click en el Item link, lo cual procede a la ventana de pago")
    public void clickItemLink() {clickElement(ITEM_LINK_BUTTON);}

    @And("Hago click en el boton Proceed to Checkout")
    public void clickProceedToCheckout() {clickElement(PROCEED_TO_CHECKOUT);}

    @And("Lleno el formulario con los datos (.*), (.*), (.*), (.*), (.*), (.*), (.*), (.*), (.*) y (.*)")
    public void fillFormulary(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8,String arg9) {
        callMethods(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
    }

    @And("Selecciono el metodos de pago")
    public void selectCheque() {clickElement(SELECTABLE_CHEQUE);}

    @Then("El usuario ve los detalles de su compra")
    public void billingDetails(){verifyElementPresence(BILLING_DETAILS);}

    @And("Hago click en el boton Place Order")
    public void clickPlaceOrder(){clickElement(PLACE_ORDER_BUTTON);}

    @Then("El usuario puede ver la información personal que suministro antes")
    public void userInfoConfirmation(){verifyElementPresence(ORDER_DETAILS);}
}
