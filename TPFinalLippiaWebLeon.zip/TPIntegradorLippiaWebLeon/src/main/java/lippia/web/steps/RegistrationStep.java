package lippia.web.steps;

import com.crowdar.core.PageSteps;
import io.cucumber.java.en.*;
import org.testng.Assert;

import static lippia.web.constants.MyAccountConstants.*;
import static lippia.web.services.GeneralToolsService.*;

public class RegistrationStep extends PageSteps {

    @When("hago click en My Account")
    public void clickMyAccount(){clickElement(MY_ACCOUNT_BUTTON);}

    @And("ingreso un (.*) correcto en la caja de texto mail del register")
    public void setCorrectEmail(String arg0){setInput(EMAIL_REGISTRATION_TEXTBOX, arg0);}

    @And("ingreso un (.*) vacio en la caja de texto password del register")
    public void setEmptyPassword(String arg1){setInput(PASSWORD_REGISTRATION_TEXTBOX, arg1);}

    @And("hago click en el boton Register")
    public void clickRegister(){clickElement(REGISTER_BUTTON);}

    @Then("el registro sera fallido y lanzara el (.*)")
    public void alertMessageEmptyPass(String arg0){Assert.assertEquals(PASSWORD_ERROR_MESSAGE, arg0);}

    @And("ingreso un (.*) vacio en la caja de texto mail del register")
    public void setEmptyEmail(String arg2){setInput(EMAIL_REGISTRATION_TEXTBOX, arg2);}

    @Then("el regitro sera fallido y lanza el (.*)")
    public void alertMessageEmptyFields(String arg1){Assert.assertEquals(PASSWORD_ERROR_MESSAGE, arg1);}
}
