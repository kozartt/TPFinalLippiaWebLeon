package lippia.web.steps;

import io.cucumber.java.en.*;

import static lippia.web.constants.MyAccountConstants.*;
import static lippia.web.services.GeneralToolsService.*;

public class MyAccountSteps {

    @And("ingreso un (.*) en el campo e-mail del login")
    public void setEmail(String arg0){setInput(LUSERNAME_TEXTBOX, arg0);}

    @And("ingreso un (.*) en el campo password del login")
    public void setPassword(String arg1){setInput(LPASSWORD_TEXTBOX, arg1);}

    @And("hago click en el boton de Login")
    public void clickLogin(){clickElement(LOGIN_BUTTON);}

    @And("hago click en el boton My Account")
    public void clickMyAccount(){clickElement(MY_ACCOUNT_BUTTON);}

    @And("hago click en el boton Account Details")
    public void clickAccountDetails(){clickElement(ACCOUNT_DETAILS);}

    @Then("ahora puedo ver los datos registrados de la cuenta")
    public void seeDetailsAccount(){verifyCurrentUrl("https://practice.automationtesting.in/my-account/edit-account/");}

    @And("hago click en el boton Log out")
    public void clickLogOutButton(){clickElement(ACCOUNT_LOGOUT);}

    @Then("regresa a la pagina de logueo")
    public void backToLoginPage(){verifyCurrentUrl("https://practice.automationtesting.in/my-account/");}
}
