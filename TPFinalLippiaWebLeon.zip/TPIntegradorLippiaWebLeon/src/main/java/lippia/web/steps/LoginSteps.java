package lippia.web.steps;

import com.crowdar.core.PageSteps;
import io.cucumber.java.en.*;

import static lippia.web.constants.MyAccountConstants.*;
import static lippia.web.services.GeneralToolsService.*;

public class LoginSteps extends PageSteps {

    @When("hago click en el menu My Account")
    public void clickMyAccount(){clickElement(MY_ACCOUNT_BUTTON);}

    @And("ingreso un (.*) modificado en la caja de texto mail del login")
    public void setChangedMailOnLogin(String arg0){setInput(LUSERNAME_TEXTBOX, arg0);}

    @And("ingreso un (.*) modificado en la caja de texto password del login")
    public void setChangedPasswordOnLogin(String arg1){setInput(LPASSWORD_TEXTBOX, arg1);}

    @And("hago click en el boton Login")
    public void hagoClickEnElBotonLogin(){clickElement(LOGIN_BUTTON);}

    @Then("el login fallara y mostrara el mensaje incorrect username password")
    public void loginFailConfirmation(){verifyElementPresence(ERROR_LOGIN_CONFIRMATION);}

    @And("ingreso un (.*) correcto en la caja de texto mail del login")
    public void setMailOnLogin(String arg2){setInput(LUSERNAME_TEXTBOX, arg2);}

    @And("ingreso un (.*) correcto en la caja de texto password del login")
    public void setPasswordOnLogin(String arg3){setInput(LPASSWORD_TEXTBOX, arg3);}

    @And("hago click en el boton Sing out")
    public void clickSingOut(){clickElement(SING_OUT_BUTTON);}

    @Then("el usuario se encontrara de nuevo en la pagina de login")
    public void singOutConfirmation(){verifyCurrentUrl("https://practice.automationtesting.in/my-account/");}
}
